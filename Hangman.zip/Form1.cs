﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Hangman
{
    public partial class formHangman : Form
    {
        //Laddar in alla bilder.
        private Bitmap[] images = { Hangman.Properties.Resources.Hangman1___kopia, Hangman.Properties.Resources.Hangman2___kopia, Hangman.Properties.Resources.Hangman3___kopia, Hangman.Properties.Resources.Hangman4___kopia, Hangman.Properties.Resources.Hangman5___kopia, Hangman.Properties.Resources.Hangman6___kopia, Hangman.Properties.Resources.Hangman7___kopia, Hangman.Properties.Resources.Hangman8___kopia, Hangman.Properties.Resources.Hangman9___kopia };

        //Variablar.
        public int wrongGuess = 0;
        private string current = "";
        private string copyCurrent = "";
        private string[] words;

        public formHangman()
        {
            InitializeComponent();
        }

        private void loadWordList()
        {
            //Öppnar upp textfilen och läser alla rader.
            string[] lines = File.ReadAllLines("Ordlista.txt");

            //Sätter längden på words array.
            words = new string[lines.Length];

            //Överför alla rader i lines till words.
            for (int i = 0; i < lines.Length; i++)
            {
                words[i] = lines[i];
            }
        }

        private void wordChoise()
        {
            //Reset
            wrongGuess = 0;
            hangImage.Image = images[wrongGuess];
            lblResult.Text = "";

            //Får ett random tal mellan 0 - längden på words array.
            int randomIndex = (new Random()).Next(words.Length);

            //Bestämmer det nuvarande ordet random.
            current = words[randomIndex];
            label1.Text = words[randomIndex];

            //Gör en kopia av ordet där varje bokstav blir ett underströck.
            copyCurrent = "";
            for (int index = 0; index < current.Length; index++)
            {
                copyCurrent += "_";
            }
            displayCopy();
        }

        //Ändar displayen så att man ser det man gissat på ordet.
        private void displayCopy()
        {
            lblShowWord.Text = ""; 
            for (int index = 0; index < current.Length; index++)
            {
                lblShowWord.Text += copyCurrent.Substring(index, 1);
                lblShowWord.Text += " ";
            }
        }

        //Gissningar
        private void guessClick(object sender, EventArgs e)
        {
            //Sätter knappen man tryckt på till choice.
            Button choice = sender as Button;

            //Stänger av den knapp man tryckt på.
            choice.Enabled = false;

            //Om ordet innehåller samma bokstav som i knapptrycket.
            if (current.Contains(choice.Text))
            {
                char[] temp = copyCurrent.ToCharArray();
                char[] find = current.ToCharArray();
                char guessChar = choice.Text.ElementAt(0);
                for (int i = 0; i < find.Length; i++)
                {
                    if (find[i] == guessChar)
                    {
                        temp[i] = guessChar;
                    }
                }
                copyCurrent = new string(temp);
                displayCopy();
            }
            else
            {
                //Ökar annars antal fel med +1.
                wrongGuess++;
            }

            //Om antal fel är mindre än 8 ändras endast bilden.
            if (wrongGuess < 8)
            {
                hangImage.Image = images[wrongGuess];
            }
            //Om man förlorar stängs alla knappar av förutom play again.
            else
            {
                hangImage.Image = images[wrongGuess];
                lblResult.Text = "You Lost!";

                foreach (var button in this.Controls.OfType<Button>())
                {
                    button.Enabled = false;
                }
                again.Enabled = true;
            }

            //Om kopian av ordet och ordet är samma vinner man, alla knappar stängs av förutom play again.
            if (copyCurrent.Equals(current))
            {
                lblResult.Text = "You Won!";

                foreach (var button in this.Controls.OfType<Button>())
                {
                    button.Enabled = false;
                }
                again.Enabled = true;
            }
       
        }

        //Startar spelet.
        private void formHangman_Load(object sender, EventArgs e)
        {
            loadWordList();
            wordChoise();
        }

        //Startar om spelet.
        private void again_Click(object sender, EventArgs e)
        {
            wordChoise();

            //Gör alla knappar klickbara.
            foreach (var button in this.Controls.OfType<Button>())
            {
                button.Enabled = true;
            }
        }
    }
}
