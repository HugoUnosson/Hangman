﻿namespace Hangman
{
    partial class formHangman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hangImage = new System.Windows.Forms.PictureBox();
            this.buttonQ = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblShowWord = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.again = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.hangImage)).BeginInit();
            this.SuspendLayout();
            // 
            // hangImage
            // 
            this.hangImage.Image = global::Hangman.Properties.Resources.Hangman1___kopia;
            this.hangImage.Location = new System.Drawing.Point(12, 12);
            this.hangImage.Name = "hangImage";
            this.hangImage.Size = new System.Drawing.Size(338, 307);
            this.hangImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.hangImage.TabIndex = 0;
            this.hangImage.TabStop = false;
            // 
            // buttonQ
            // 
            this.buttonQ.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQ.Location = new System.Drawing.Point(25, 325);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(50, 50);
            this.buttonQ.TabIndex = 1;
            this.buttonQ.Text = "q";
            this.buttonQ.UseVisualStyleBackColor = true;
            this.buttonQ.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonW
            // 
            this.buttonW.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonW.Location = new System.Drawing.Point(81, 325);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(50, 50);
            this.buttonW.TabIndex = 2;
            this.buttonW.Text = "w";
            this.buttonW.UseVisualStyleBackColor = true;
            this.buttonW.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonE
            // 
            this.buttonE.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonE.Location = new System.Drawing.Point(137, 325);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(50, 50);
            this.buttonE.TabIndex = 3;
            this.buttonE.Text = "e";
            this.buttonE.UseVisualStyleBackColor = true;
            this.buttonE.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonR
            // 
            this.buttonR.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonR.Location = new System.Drawing.Point(193, 325);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(50, 50);
            this.buttonR.TabIndex = 4;
            this.buttonR.Text = "r";
            this.buttonR.UseVisualStyleBackColor = true;
            this.buttonR.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonT
            // 
            this.buttonT.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonT.Location = new System.Drawing.Point(249, 325);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(50, 50);
            this.buttonT.TabIndex = 5;
            this.buttonT.Text = "t";
            this.buttonT.UseVisualStyleBackColor = true;
            this.buttonT.Click += new System.EventHandler(this.guessClick);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold);
            this.lblResult.Location = new System.Drawing.Point(356, 50);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(116, 25);
            this.lblResult.TabIndex = 6;
            this.lblResult.Text = "resultat";
            // 
            // lblShowWord
            // 
            this.lblShowWord.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold);
            this.lblShowWord.Location = new System.Drawing.Point(356, 270);
            this.lblShowWord.Name = "lblShowWord";
            this.lblShowWord.Size = new System.Drawing.Size(445, 49);
            this.lblShowWord.TabIndex = 7;
            this.lblShowWord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(356, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 38);
            this.label1.TabIndex = 8;
            this.label1.Text = "ord";
            // 
            // buttonP
            // 
            this.buttonP.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonP.Location = new System.Drawing.Point(529, 325);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(50, 50);
            this.buttonP.TabIndex = 13;
            this.buttonP.Text = "p";
            this.buttonP.UseVisualStyleBackColor = true;
            this.buttonP.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonO
            // 
            this.buttonO.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonO.Location = new System.Drawing.Point(473, 325);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(50, 50);
            this.buttonO.TabIndex = 12;
            this.buttonO.Text = "o";
            this.buttonO.UseVisualStyleBackColor = true;
            this.buttonO.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonI
            // 
            this.buttonI.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonI.Location = new System.Drawing.Point(417, 325);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(50, 50);
            this.buttonI.TabIndex = 11;
            this.buttonI.Text = "i";
            this.buttonI.UseVisualStyleBackColor = true;
            this.buttonI.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonU
            // 
            this.buttonU.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonU.Location = new System.Drawing.Point(361, 325);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(50, 50);
            this.buttonU.TabIndex = 10;
            this.buttonU.Text = "u";
            this.buttonU.UseVisualStyleBackColor = true;
            this.buttonU.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonY
            // 
            this.buttonY.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonY.Location = new System.Drawing.Point(305, 325);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(50, 50);
            this.buttonY.TabIndex = 9;
            this.buttonY.Text = "y";
            this.buttonY.UseVisualStyleBackColor = true;
            this.buttonY.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonL
            // 
            this.buttonL.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonL.Location = new System.Drawing.Point(485, 381);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(50, 50);
            this.buttonL.TabIndex = 23;
            this.buttonL.Text = "l";
            this.buttonL.UseVisualStyleBackColor = true;
            this.buttonL.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonK
            // 
            this.buttonK.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonK.Location = new System.Drawing.Point(429, 381);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(50, 50);
            this.buttonK.TabIndex = 22;
            this.buttonK.Text = "k";
            this.buttonK.UseVisualStyleBackColor = true;
            this.buttonK.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonJ
            // 
            this.buttonJ.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJ.Location = new System.Drawing.Point(373, 381);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(50, 50);
            this.buttonJ.TabIndex = 21;
            this.buttonJ.Text = "j";
            this.buttonJ.UseVisualStyleBackColor = true;
            this.buttonJ.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonH
            // 
            this.buttonH.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonH.Location = new System.Drawing.Point(317, 381);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(50, 50);
            this.buttonH.TabIndex = 20;
            this.buttonH.Text = "h";
            this.buttonH.UseVisualStyleBackColor = true;
            this.buttonH.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonG
            // 
            this.buttonG.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonG.Location = new System.Drawing.Point(261, 381);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(50, 50);
            this.buttonG.TabIndex = 19;
            this.buttonG.Text = "g";
            this.buttonG.UseVisualStyleBackColor = true;
            this.buttonG.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonF
            // 
            this.buttonF.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonF.Location = new System.Drawing.Point(205, 381);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(50, 50);
            this.buttonF.TabIndex = 18;
            this.buttonF.Text = "f";
            this.buttonF.UseVisualStyleBackColor = true;
            this.buttonF.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonD
            // 
            this.buttonD.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonD.Location = new System.Drawing.Point(149, 381);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(50, 50);
            this.buttonD.TabIndex = 17;
            this.buttonD.Text = "d";
            this.buttonD.UseVisualStyleBackColor = true;
            this.buttonD.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonS
            // 
            this.buttonS.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonS.Location = new System.Drawing.Point(93, 381);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(50, 50);
            this.buttonS.TabIndex = 16;
            this.buttonS.Text = "s";
            this.buttonS.UseVisualStyleBackColor = true;
            this.buttonS.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonA
            // 
            this.buttonA.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonA.Location = new System.Drawing.Point(37, 381);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(50, 50);
            this.buttonA.TabIndex = 15;
            this.buttonA.Text = "a";
            this.buttonA.UseVisualStyleBackColor = true;
            this.buttonA.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonM
            // 
            this.buttonM.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonM.Location = new System.Drawing.Point(389, 437);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(50, 50);
            this.buttonM.TabIndex = 32;
            this.buttonM.Text = "m";
            this.buttonM.UseVisualStyleBackColor = true;
            this.buttonM.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonN
            // 
            this.buttonN.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonN.Location = new System.Drawing.Point(333, 437);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(50, 50);
            this.buttonN.TabIndex = 31;
            this.buttonN.Text = "n";
            this.buttonN.UseVisualStyleBackColor = true;
            this.buttonN.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonB
            // 
            this.buttonB.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonB.Location = new System.Drawing.Point(277, 437);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(50, 50);
            this.buttonB.TabIndex = 30;
            this.buttonB.Text = "b";
            this.buttonB.UseVisualStyleBackColor = true;
            this.buttonB.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonV
            // 
            this.buttonV.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonV.Location = new System.Drawing.Point(221, 437);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(50, 50);
            this.buttonV.TabIndex = 29;
            this.buttonV.Text = "v";
            this.buttonV.UseVisualStyleBackColor = true;
            this.buttonV.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonC
            // 
            this.buttonC.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonC.Location = new System.Drawing.Point(165, 437);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(50, 50);
            this.buttonC.TabIndex = 28;
            this.buttonC.Text = "c";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonX
            // 
            this.buttonX.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonX.Location = new System.Drawing.Point(109, 437);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(50, 50);
            this.buttonX.TabIndex = 27;
            this.buttonX.Text = "x";
            this.buttonX.UseVisualStyleBackColor = true;
            this.buttonX.Click += new System.EventHandler(this.guessClick);
            // 
            // buttonZ
            // 
            this.buttonZ.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonZ.Location = new System.Drawing.Point(53, 437);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(50, 50);
            this.buttonZ.TabIndex = 26;
            this.buttonZ.Text = "z";
            this.buttonZ.UseVisualStyleBackColor = true;
            this.buttonZ.Click += new System.EventHandler(this.guessClick);
            // 
            // again
            // 
            this.again.Font = new System.Drawing.Font("Liberation Mono", 11F, System.Drawing.FontStyle.Bold);
            this.again.Location = new System.Drawing.Point(149, 493);
            this.again.Name = "again";
            this.again.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.again.Size = new System.Drawing.Size(301, 50);
            this.again.TabIndex = 33;
            this.again.Text = "Play again";
            this.again.UseVisualStyleBackColor = true;
            this.again.Click += new System.EventHandler(this.again_Click);
            // 
            // formHangman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(885, 570);
            this.Controls.Add(this.again);
            this.Controls.Add(this.buttonM);
            this.Controls.Add(this.buttonN);
            this.Controls.Add(this.buttonB);
            this.Controls.Add(this.buttonV);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.buttonX);
            this.Controls.Add(this.buttonZ);
            this.Controls.Add(this.buttonL);
            this.Controls.Add(this.buttonK);
            this.Controls.Add(this.buttonJ);
            this.Controls.Add(this.buttonH);
            this.Controls.Add(this.buttonG);
            this.Controls.Add(this.buttonF);
            this.Controls.Add(this.buttonD);
            this.Controls.Add(this.buttonS);
            this.Controls.Add(this.buttonA);
            this.Controls.Add(this.buttonP);
            this.Controls.Add(this.buttonO);
            this.Controls.Add(this.buttonI);
            this.Controls.Add(this.buttonU);
            this.Controls.Add(this.buttonY);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblShowWord);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.buttonT);
            this.Controls.Add(this.buttonR);
            this.Controls.Add(this.buttonE);
            this.Controls.Add(this.buttonW);
            this.Controls.Add(this.buttonQ);
            this.Controls.Add(this.hangImage);
            this.Name = "formHangman";
            this.Text = "Hangman";
            this.Load += new System.EventHandler(this.formHangman_Load);
            ((System.ComponentModel.ISupportInitialize)(this.hangImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox hangImage;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblShowWord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Button again;
    }
}

